from collections import deque
import heapq
def bfs(graph, start_node, search_node=None):
    # graph: a dictionary representing the graph to be traversed.
    # start_node: a string representing the starting node of the traversal.
    # search_node: an optional string representing the node being searched for in the graph.
    # Note: If the given start_node belongs to one strongly connected component then the other nodes belong to that
           # particular component can only be traversed. But the nodes belonging to other components must not be traversed
           # if those nodes were not reachable from the given start_node.

    #The output depends on whether the search_node is provided or not:
        #1. If search_node is provided, the function returns 1 if the node is found during the search and 0 otherwise.
        #2. If search_node is not provided, the function returns a list containing the order in which the nodes were visited during the search.

    #Useful code snippets (not necessary but you can use if required)
    visited = set()
    
    bfsQueue = deque([start_node])
    
    path = []
    
    while bfsQueue:
        node = bfsQueue.popleft()
        
        if node in visited:
            continue
        
        visited.add(node)
        path.append(node)
        
        if search_node and node == search_node:
            return 1
        
        for neighbor in graph[node]:
            if neighbor not in visited:
                bfsQueue.append(neighbor)
                
    if search_node:
        return 0
    else:
        return path # search node not provided, return entire path [list of nconst values of nodes visited]


def dfs(graph, start_node, visited=None, path=None, search_node=None):
    # graph: a dictionary representing the graph
    # start_node: the starting node for the search
    # visited: a set of visited nodes (optional, default is None)
    # path: a list of nodes in the current path (optional, default is None)
    # search_node: the node to search for (optional, default is None)

    # Note1: The optional parameters “visited” and “path” are initially not required to be passed as inputs but needs to be
            # updated recursively during the search implementation. If not required for your implementation purposes they can
            # be ignored and can be removed from the parameters.

    # Note2: If the given start_node belongs to one strongly connected component then the other nodes belong to that
           # particular component can only be traversed. But the nodes belonging to other components must not be traversed
           # if those nodes were not reachable from the given start_node.

    # The function returns:
        # 1. If search_node is provided, the function returns 1 if the node is found and 0 if it is not found.
        # 2. If search_node is not provided, the function returns a list containing the order in which the nodes were visited during the search.

    #Useful code snippets (not necessary but you can use if required)
    if visited is None:
        visited = set()
    if path is None:
        path = []

    # add start_node to visited set and path list
    visited.add(start_node)
    path.append(start_node)

    # base case for recursion
    if start_node == search_node:
        return 1
    
    # Recursively explore neighbors of current node
    for neighbor in graph[start_node]:
        # Check if neighbor belongs to the same strongly connected component
        if neighbor in visited or not can_reach(graph, start_node, neighbor):
            continue
        # Recursively call dfs on neighbor
        result = dfs(graph, neighbor, visited, path, search_node)
        if result == 1:
            return 1
    
    # If search_node is not provided, return the order in which nodes were visited
    if search_node is None:
        return path
    
    # If search_node was not found, return 0
    return 0  # search node not provided, return entire path [list of nconst id's of nodes visited]

def can_reach(graph, start_node, target_node):
    # Initialize visited set and stack for DFS traversal
    visited = set()
    stack = [start_node]

    # Traverse the graph using DFS
    while stack:
        # Get the next node to visit from the stack
        node = stack.pop()

        # If the node is the target node, return True
        if node == target_node:
            return True

        # Mark the node as visited
        visited.add(node)

        # Add unvisited neighbors to the stack
        for neighbor in graph.get(node, {}):
            if neighbor not in visited:
                stack.append(neighbor)

    # If target node is not found, return False
    return False

def dijkstra(graph, start_node, end_node):
    # graph: a dictionary representing the graph where the keys are the nodes and the values
            # are dictionaries representing the edges and their weights.
    # start_node: the starting node to begin the search.
    # end_node: the node that we want to reach.

    # Outputs:
        #1. If the end_node is not reachable from the start_node, the function returns 0.

        #2. If the end_node is reachable from the start_node, the function returns a list containing three elements:
                #2.1 The first element is a list representing the shortest path from start_node to end_node.
                     #[list of nconst values in the visited order]
                #2.2 The second element is the total distance of the shortest path.
                     #(summation of the distances or edge weights between minimum visited nodes)
                #2.3 The third element is Hop Count between start_node and end_node.

    distances = {node: float('inf') for node in graph}
    distances[start_node] = 0
    result = [(0, start_node)]

    hops = {node: float('inf') for node in graph}
    hops[start_node] = 0
    prev = {node: None for node in graph}

    while result:
        curr_dist, curr_node = heapq.heappop(result)

        if curr_node == end_node:
            path = []
            node = end_node
            while node is not None:
                path.append(node)
                node = prev[node]
            path.reverse()
            return path, distances[end_node], hops[end_node]

        if curr_dist > distances[curr_node]:
            continue

        for neighbor, weight in graph[curr_node].items():
            distance = curr_dist + weight

            if distance < distances[neighbor]:
                distances[neighbor] = distance
                hops[neighbor] = hops[curr_node] + 1
                prev[neighbor] = curr_node

                heapq.heappush(result, (distance, neighbor))

    # If we reach here, end_node is not reachable from start_node
    return 0




# (strongly connected components)
def kosaraju(graph):
    # graph: a dictionary representing the graph where the keys are the nodes and the values
            # are dictionaries representing the edges and their weights.
    #Note: Here you need to call dfs function multiple times so you can Implement seperate
         # kosaraju_dfs function if required.

    #The output:
        #list of strongly connected components in the graph,
          #where each component is a list of nodes. each component:[nconst2, nconst3, nconst8,...] -> list of nconst id's.
    # First, run DFS on the original graph and keep track of the order in which nodes are finished.
    reverse_graph = {node: {} for node in graph}
    for node, edges in graph.items():
        for neighbor, weight in edges.items():
            reverse_graph[neighbor][node] = weight

    visited = set()
    orderList = []

    def kosaraju_dfs1(node):
        visited.add(node)
        for neighbor in reverse_graph[node]:
            if neighbor not in visited:
                kosaraju_dfs1(neighbor)
        orderList.append(node)

    for node in graph:
        if node not in visited:
            kosaraju_dfs1(node)

    visited.clear()
    components = []

    def kosaraju_dfs2(node, component):
        visited.add(node)
        component.append(node)
        for neighbor in graph[node]:
            if neighbor not in visited:
                kosaraju_dfs2(neighbor, component)

    while orderList:
        node = orderList.pop()
        if node not in visited:
            component = []
            kosaraju_dfs2(node, component)
            components.append(component)

    return components